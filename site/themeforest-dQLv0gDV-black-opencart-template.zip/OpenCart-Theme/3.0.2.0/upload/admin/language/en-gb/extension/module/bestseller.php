<?php
// Heading
$_['heading_title']    = 'Bestsellers';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified bestsellers module!';
$_['text_edit']        = 'Edit Bestsellers Module';

// Entry
$_['entry_name']       = 'Module Name';
$_['entry_carousel_enable'] = 'Enable Carousel';
$_['entry_limit']      		= 'Total products in carousel limit';
$_['entry_itemspage']    	= 'Visible carousel items';
$_['entry_itemspage1']    	= 'Visible carousel items Desktop Small';
$_['entry_itemspage2']    	= 'Visible carousel items Tablet';
$_['entry_itemspage3']    	= 'Visible carousel items Tablet Small';
$_['entry_auto_play'] 		= 'Auto play';
$_['entry_pause_on_hover'] 	= 'Pause on hover';
$_['entry_show_pagination'] = 'Show pagination controls';
$_['entry_show_navigation'] = 'Show navigation controls';
$_['entry_image']      = 'Image (W x H) and Resize Type';
$_['entry_width']      = 'Width';
$_['entry_height']     = 'Height';
$_['entry_status']     = 'Status';

// Help
$_['help_auto_play']		= 'Auto play carousel (on/off)';
$_['help_pause_on_hover'] 	= 'Pause carousel on hover (on/off)';
$_['help_show_pagination'] 	= 'Show carousel pagination controls at bottom (on/off)';
$_['help_show_navigation'] 	= 'Show carousel navigation controls(on/off)';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify bestsellers module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';