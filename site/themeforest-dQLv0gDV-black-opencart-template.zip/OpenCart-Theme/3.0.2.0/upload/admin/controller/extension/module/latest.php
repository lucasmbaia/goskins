<?php
class ControllerExtensionModuleLatest extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/latest');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/module');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_setting_module->addModule('latest', $this->request->post);
			} else {
				$this->model_setting_module->editModule($this->request->get['module_id'], $this->request->post);
			}

			$this->cache->delete('product');

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		$data['entry_carousel_enable'] = $this->language->get('entry_carousel_enable');
			
		$data['entry_itemspage'] = $this->language->get('entry_itemspage');
		
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		
		$data['entry_itemspage1'] = $this->language->get('entry_itemspage1');
		$data['entry_itemspage2'] = $this->language->get('entry_itemspage2');
		$data['entry_itemspage3'] = $this->language->get('entry_itemspage3');
		
		
		$data['entry_auto_play'] = $this->language->get('entry_auto_play');
		$data['entry_pause_on_hover'] = $this->language->get('entry_pause_on_hover');
		$data['entry_show_pagination'] = $this->language->get('entry_show_pagination');
		$data['entry_show_navigation'] = $this->language->get('entry_show_navigation');
		
		$data['help_auto_play'] = $this->language->get('help_auto_play');
		$data['help_pause_on_hover'] = $this->language->get('help_pause_on_hover');
		$data['help_show_pagination'] = $this->language->get('help_show_pagination');
		$data['help_show_navigation'] = $this->language->get('help_show_pagination');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['width'])) {
			$data['error_width'] = $this->error['width'];
		} else {
			$data['error_width'] = '';
		}

		if (isset($this->error['height'])) {
			$data['error_height'] = $this->error['height'];
		} else {
			$data['error_height'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/latest', 'user_token=' . $this->session->data['user_token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/latest', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/latest', 'user_token=' . $this->session->data['user_token'], true);
		} else {
			$data['action'] = $this->url->link('extension/module/latest', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true);
		}

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_setting_module->getModule($this->request->get['module_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['limit'])) {
			$data['limit'] = $this->request->post['limit'];
		} elseif (!empty($module_info)) {
			$data['limit'] = $module_info['limit'];
		} else {
			$data['limit'] = 5;
		}

		// carousel visible items per page
			
		// carousel enable
		if (isset($this->request->post['carousel_enable'])) {
			$data['carousel_enable'] = $this->request->post['carousel_enable'];
		} elseif (!empty($module_info)&&isset($module_info['carousel_enable'])) {
			$data['carousel_enable'] = $module_info['carousel_enable'];
		} else {
			$data['carousel_enable'] = 1;
		}				
			
		if (isset($this->request->post['itemspage'])) {
			$data['itemspage'] = $this->request->post['itemspage'];
		} elseif (!empty($module_info)&&isset($module_info['itemspage'])) {
			$data['itemspage'] = $module_info['itemspage'];
		} else {
			$data['itemspage'] = 4;
		}
		
		// carousel visible items per page desktop small
		if (isset($this->request->post['itemspage1'])) {
			$data['itemspage1'] = $this->request->post['itemspage1'];
		} elseif (!empty($module_info)&&isset($module_info['itemspage1'])) {
			$data['itemspage1'] = $module_info['itemspage1'];
		} else {
			$data['itemspage1'] = 3;
		}
		
		// carousel visible items per page tablet
		if (isset($this->request->post['itemspage2'])) {
			$data['itemspage2'] = $this->request->post['itemspage2'];
		} elseif (!empty($module_info)&&isset($module_info['itemspage2'])) {
			$data['itemspage2'] = $module_info['itemspage2'];
		} else {
			$data['itemspage2'] = 2;
		}
		
		// carousel visible items per page tablet small
		if (isset($this->request->post['itemspage3'])) {
			$data['itemspage3'] = $this->request->post['itemspage3'];
		} elseif (!empty($module_info)&&isset($module_info['itemspage3'])) {
			$data['itemspage3'] = $module_info['itemspage3'];
		} else {
			$data['itemspage3'] = 1;
		}		

		// carousel auto play
		if (isset($this->request->post['auto_play'])) {
			$data['auto_play'] = $this->request->post['auto_play'];
		} elseif (!empty($module_info)&&isset($module_info['auto_play'])) {
			$data['auto_play'] = $module_info['auto_play'];
		} else {
			$data['auto_play'] = 1;
		}	

		// carousel pause on hover
		if (isset($this->request->post['pause_on_hover'])) {
			$data['pause_on_hover'] = $this->request->post['pause_on_hover'];
		} elseif (!empty($module_info)&&isset($module_info['pause_on_hover'])) {
			$data['pause_on_hover'] = $module_info['pause_on_hover'];
		} else {
			$data['pause_on_hover'] = 1;
		}	

		// carousel show pagination
		if (isset($this->request->post['show_pagination'])) {
			$data['show_pagination'] = $this->request->post['show_pagination'];
		} elseif (!empty($module_info)&&isset($module_info['show_pagination'])) {
			$data['show_pagination'] = $module_info['show_pagination'];
		} else {
			$data['show_pagination'] = 1;
		}	

		// carousel show pagination
		if (isset($this->request->post['show_navigation'])) {
			$data['show_navigation'] = $this->request->post['show_pagination'];
		} elseif (!empty($module_info)&&isset($module_info['show_navigation'])) {
			$data['show_navigation'] = $module_info['show_navigation'];
		} else {
			$data['show_navigation'] = 1;
		}

		if (isset($this->request->post['width'])) {
			$data['width'] = $this->request->post['width'];
		} elseif (!empty($module_info)) {
			$data['width'] = $module_info['width'];
		} else {
			$data['width'] = 200;
		}

		if (isset($this->request->post['height'])) {
			$data['height'] = $this->request->post['height'];
		} elseif (!empty($module_info)) {
			$data['height'] = $module_info['height'];
		} else {
			$data['height'] = 200;
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/latest', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/latest')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if (!$this->request->post['width']) {
			$this->error['width'] = $this->language->get('error_width');
		}

		if (!$this->request->post['height']) {
			$this->error['height'] = $this->language->get('error_height');
		}

		return !$this->error;
	}
}