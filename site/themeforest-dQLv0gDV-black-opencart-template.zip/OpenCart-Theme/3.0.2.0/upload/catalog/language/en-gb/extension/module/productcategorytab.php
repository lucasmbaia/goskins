<?php
// Heading
$_['heading_title'] = 'Product By Category Tab';